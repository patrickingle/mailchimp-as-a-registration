<?php
$mcdomain = $_SERVER['HTTP_HOST'];   
?>
